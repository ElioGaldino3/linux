
description "npc_control"

client_scripts{ 
  "lib/enum.lua",
  "cfg/npcs.lua",
  "client.lua"
}