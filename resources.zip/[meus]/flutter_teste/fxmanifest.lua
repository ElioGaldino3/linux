fx_version "bodacious"

game "gta5"

ui_page "page/index.html"

files {
    "page/flutter_service_worker.js"
    "page/main.dart.js"
}

client_script "cl.lua"