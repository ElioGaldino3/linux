-- Resource Metadata
fx_version 'cerulean'
games {'gta5'}

author 'Elio Galdino'
description 'PVP ON'
version '0.0.1'

-- What to run
client_scripts {
    'client.lua'
}