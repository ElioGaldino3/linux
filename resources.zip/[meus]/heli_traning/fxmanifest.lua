-- Resource Metadata
fx_version 'cerulean'
games {'gta5'}

author 'Elio Galdino'
description 'Cria um helicóptero e transporta você pra lá'
version '0.0.1'

-- What to run
client_scripts {
    'Client.net.dll'
}