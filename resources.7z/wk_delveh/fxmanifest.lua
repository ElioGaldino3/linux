-- Delete Vehicle script written by WolfKnight
-- With credit to Mr.Scammer, thers, Zanax and Konijima!
-- Version 1.1.0

-- Define the FX Server version and game type
fx_version "bodacious"
game "gta5"

name "Delete Vehicles"
description "Deletes vehicles!"
author "WolfKnight"
version "1.1.0"

-- Add a client script 
client_script "client.lua"